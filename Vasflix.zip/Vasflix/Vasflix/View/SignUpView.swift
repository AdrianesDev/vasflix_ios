//
//  SignUpView.swift
//  Vasflix
//
//  Created by Adrian Castañeda on 03/04/24.
//

import SwiftUI

struct SignUpView: View {
    var body: some View {
        Text("Sing Up Page")
    }
}

#Preview {
    SignUpView()
}
