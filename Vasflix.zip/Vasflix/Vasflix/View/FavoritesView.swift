//
//  FavoritesView.swift
//  Vasflix
//
//  Created by Adrian Castañeda on 05/04/24.
//

import SwiftUI

struct FavoritesView: View {
    var body: some View {
        Text("Favorite view")
    }
}

#Preview {
    FavoritesView()
}
