//
//  .env.swift
//  Vasflix
//
//  Created by Adrian Castañeda on 14/04/24.
//

import Foundation

let API_KEY = "981e18de5dd46e9deb7cc01ab0dc27e5"
